package codecompetition;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class CustomerFrame extends JFrame{
	
	CustomerFrame()
	{
		super("CustomerMenu");
		this.setResizable(false);
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (int)screenSize.getWidth();
		int y = (int)screenSize.getHeight();
		this.setSize(x,y);
		
		JLabel jlb = new JLabel("Customer Menu");
		jlb.setForeground(Color.white);
		jlb.setFont(new Font("Arial", Font.PLAIN, 100));
		JPanel pane1 = new JPanel();
		pane1.setBackground(Color.gray);
		pane1.add(jlb);
		
		JPanel pane2 = new JPanel();
		JPanel pane3 = new JPanel();
		JPanel jp1 = new JPanel();
		jp1.setLayout(new BoxLayout(jp1,BoxLayout.Y_AXIS));
		jp1.add(pane1);
		
		
		
		JButton add = new JButton("ADD");
		
		
		JPanel pane4 = new JPanel();
		
		JPanel pane5 = new JPanel();
		pane5.setLayout(new BoxLayout(pane5,BoxLayout.Y_AXIS));
		
		JButton Shop = new JButton("BOOK SLOT");
		
		
		
		Shop.setFont(new Font("Arial", Font.PLAIN, 75));
		Shop.setBackground(Color.orange);
		
		
		
		JButton addcust = new JButton("Add");
		addcust.setAlignmentX(LEFT_ALIGNMENT);
		addcust.setFont(new Font("Arial", Font.PLAIN, 50));
		addcust.setBackground(Color.orange);
		JLabel header = new JLabel("Register");
		JLabel first = new JLabel("Enter FirstName : ");
		first.setFont(new Font("Arial", Font.PLAIN, 50));
		JTextField jf = new JTextField();
		jf.setFont(new Font("Arial", Font.PLAIN, 50));
		JLabel last = new JLabel("Enter LastName : ");
		last.setFont(new Font("Arial", Font.PLAIN, 50));
		JTextField jl = new JTextField();
		jl.setFont(new Font("Arial", Font.PLAIN, 50));
		header.setFont(new Font("Arial", Font.PLAIN, 50));
		
		
		Shop.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				BookslotFrame bsf = new BookslotFrame();
				CustomerFrame.this.dispose();
			}
		});
		
		addcust.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				if(((jf.getText())=="")||((jf.getText())==""))
				{
					JOptionPane.showMessageDialog(null, "EMPTY","ERROR",JOptionPane.ERROR_MESSAGE);
				}
				else
				{
				
					try {
					Connection mycon=DriverManager.getConnection("jdbc:mysql://localhost/compete","root","12345");
					Statement s=mycon.createStatement();
					ResultSet rs;
					
					String first=jf.getText();
					String last=jl.getText();
					
					s.execute("SELECT * FROM customer WHERE fname ='"+first+"' AND lname ='"+last+"'");
					rs=s.getResultSet();
					if(rs.next())
					{
						JOptionPane.showMessageDialog(null, "YOU ALREADY EXIST","ERROR",JOptionPane.ERROR_MESSAGE);
					}
					else {
						s.execute("INSERT INTO customer VALUES('"+first+"','"+last+"')");
						 JOptionPane.showMessageDialog(null,"SUCESS","DONE",JOptionPane.PLAIN_MESSAGE);
					}
					
					s.close();
					mycon.close();
	
					}
					catch(SQLException ae)
					{
						ae.printStackTrace();
					}
				}
			}
				
			
			
		});
		
		
		header.setForeground(Color.gray);
		pane5.add(header);
		pane5.add(first);
		pane5.add(jf);
		pane5.add(last);
		pane5.add(jl);
		pane5.add(addcust);
		pane4.add(pane5);
		jp1.add(pane4);
		
	
		
		
		
		
		
		
		
		JButton back = new JButton("Back");
		
		back.addActionListener(new ActionListener(){
			
			public void actionPerformed(ActionEvent e)
			{
				Welcome_frame wf = new Welcome_frame();
				CustomerFrame.this.dispose();;
			}
		});
		
		
		back.setBackground(Color.orange);
		back.setFont(new Font("Arial", Font.PLAIN, 75));
		add.setFont(new Font("Arial", Font.PLAIN, 75));
		add.setBackground(Color.orange);
		
		jp1.add(pane4);
		pane3.add(Shop);
		pane3.add(back);
		pane3.setBackground(Color.gray);
		jp1.add(pane3);
		
		
		
		this.add(jp1);
		this.setVisible(true);
	}
	

}
