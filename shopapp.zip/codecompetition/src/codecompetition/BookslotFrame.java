package codecompetition;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class BookslotFrame extends JFrame{

	BookslotFrame()
	{
		super("Slots Menu");
		this.setResizable(false);
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (int)screenSize.getWidth();
		int y = (int)screenSize.getHeight();
		this.setSize(x,y);
		
		JLabel jlb = new JLabel("Slots Available");
		jlb.setForeground(Color.white);
		jlb.setFont(new Font("Arial", Font.PLAIN, 100));
		JPanel pane1 = new JPanel();
		pane1.setBackground(Color.gray);
		pane1.add(jlb);
		
		JPanel pane2 = new JPanel();
		JPanel pane3 = new JPanel();
		JPanel jp1 = new JPanel();
		jp1.setLayout(new BoxLayout(jp1,BoxLayout.Y_AXIS));
		jp1.add(pane1);
		
		
		
		JButton add = new JButton("Enter");
		
		
		JPanel pane4 = new JPanel();
		pane4.setLayout(new GridLayout(0,2,5,2));
		
		JLabel advert = new JLabel("#RESSOULAKAZ");
		advert.setFont((new Font("Arial", Font.PLAIN, 75)));
		
		advert.setForeground(Color.red);
		JPanel pane7 = new JPanel();
		pane7.setAlignmentX(LEFT_ALIGNMENT);
		pane7.add(advert);
		JPanel pane6 = new JPanel();
		pane6.setLayout(new BoxLayout(pane6,BoxLayout.Y_AXIS));
		JLabel footer = new JLabel("Area Store Info");
		footer.setForeground(Color.gray);
		footer.setFont(new Font("Arial", Font.PLAIN, 50));
		JLabel sName = new JLabel("Enter Store Name : ");
		sName.setFont(new Font("Arial", Font.PLAIN, 50));
		JTextField storetf = new JTextField();
		storetf.setFont(new Font("Arial", Font.PLAIN, 50));
		storetf.setPreferredSize( new Dimension( 5,1) );
		pane6.add(footer);
		pane6.add(sName);
		pane6.add(storetf);
		pane6.add(pane7);
		
		
		
		JPanel pane5 = new JPanel();
		pane5.setLayout(new BoxLayout(pane5,BoxLayout.Y_AXIS));
		
		JButton Shop = new JButton("Process Inputs");
		
		
		
		Shop.setFont(new Font("Arial", Font.PLAIN, 75));
		Shop.setBackground(Color.orange);
		
		
		
		JButton addcust = new JButton("Add");
		addcust.setAlignmentX(LEFT_ALIGNMENT);
		addcust.setFont(new Font("Arial", Font.PLAIN, 50));
		addcust.setBackground(Color.orange);
		JLabel header = new JLabel("Customer info");
		JLabel first = new JLabel("Enter FirstName : ");
		first.setFont(new Font("Arial", Font.PLAIN, 50));
		JTextField jf = new JTextField();
		jf.setFont(new Font("Arial", Font.PLAIN, 50));
		JLabel last = new JLabel("Enter LastName : ");
		last.setFont(new Font("Arial", Font.PLAIN, 50));
		JTextField jl = new JTextField();
		jl.setFont(new Font("Arial", Font.PLAIN, 50));
		header.setFont(new Font("Arial", Font.PLAIN, 50));
		
		
		
		
		addcust.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				try {
					Connection mycon=DriverManager.getConnection("jdbc:mysql://localhost/compete","root","12345");
					Statement s=mycon.createStatement();
					ResultSet rs;
					
					String first=jf.getText();
					String last=jl.getText();
					
					s.execute("SELECT * FROM customer WHERE fname ='"+first+"' AND lname ='"+last+"'");
					rs=s.getResultSet();
					if(rs.next())
					{
						JOptionPane.showMessageDialog(null, "YOU ALREADY EXIST","ERROR",JOptionPane.ERROR_MESSAGE);
					}
					else {
						s.execute("INSERT INTO customer VALUES('"+first+"','"+last+"')");
						 JOptionPane.showMessageDialog(null,"SUCESS","DONE",JOptionPane.PLAIN_MESSAGE);
					}
					
					s.close();
					mycon.close();
	
			}
			catch(SQLException ae)
			{
				ae.printStackTrace();
			}
			}
		});
		
		
		header.setForeground(Color.gray);
		pane5.add(header);
		pane5.add(first);
		pane5.add(jf);
		pane5.add(last);
		pane5.add(jl);
		pane5.add(addcust);
		pane4.add(pane5);
		pane4.add(pane6);
		jp1.add(pane4);
		
		JButton back = new JButton("Back");
		
		back.addActionListener(new ActionListener(){
			
			public void actionPerformed(ActionEvent e)
			{
				CustomerFrame cf = new CustomerFrame();
				BookslotFrame.this.dispose();;
			}
		});
		
		
		back.setBackground(Color.orange);
		back.setFont(new Font("Arial", Font.PLAIN, 75));
		add.setFont(new Font("Arial", Font.PLAIN, 75));
		add.setBackground(Color.orange);
		
		jp1.add(pane4);
		pane3.add(Shop);
		pane3.add(back);
		pane3.setBackground(Color.gray);
		jp1.add(pane3);
		
		
		
		this.add(jp1);
		this.setVisible(true);
	}
	
	

}
