package codecompetition;

public class shopmain {

	public static void main(String[] args) {
		Welcome_frame welcome = new Welcome_frame();

	}

}
