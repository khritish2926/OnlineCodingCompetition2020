package codecompetition;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;


public class Welcome_frame extends JFrame {

	Welcome_frame()
	{
		super("Welcome Users");
		this.setResizable(false);
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (int)screenSize.getWidth();
		int y = (int)screenSize.getHeight();
		this.setSize(x,y);
	
		JButton bt1 = new JButton("SHOP SECTION");
	
		//adding action listener to bt1.
		bt1.addActionListener(new ActionListener()
		{
		
			public void actionPerformed(ActionEvent e) {
			Shopmenu frame2 = new Shopmenu();
			Welcome_frame.this.dispose();;
		}
			
		});
	
		JButton bt2 = new JButton("CUSTOMER SECTION");
	
		
		bt2.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				CustomerFrame frame3 = new CustomerFrame();
				Welcome_frame.this.setVisible(false);
			}
			});
		bt1.setBackground(Color.orange);
		bt1.setFont(new Font("Arial", Font.PLAIN, 75));
		bt2.setFont(new Font("Arial", Font.PLAIN, 75));
		bt2.setBackground(Color.orange);
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(0,2));
		panel.add(bt1);
		panel.add(bt2);
		this.add(panel);
		this.setVisible(true);
		}
	
	

}
