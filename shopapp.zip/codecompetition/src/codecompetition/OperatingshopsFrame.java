package codecompetition;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;

public class OperatingshopsFrame extends JFrame{
	
		static Connection mycon;
		static Statement s;
		static ResultSet rs;
		static ResultSetMetaData rmsd;
			OperatingshopsFrame()
				{
					this.setTitle("OperatingShops");
					this.setResizable(false);
					Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
					int x = (int)screenSize.getWidth();
					int y = (int)screenSize.getHeight();
					this.setSize(x,y);
			
						//creating a panel to store textarea.
			
						JPanel panel1 = new JPanel(new GridLayout(3,5,5,5));
						panel1.setBackground(Color.gray);
						JPanel panel3 =new JPanel();
			
						
						try {
								mycon=DriverManager.getConnection("jdbc:mysql://localhost/compete","root","12345");
								s=mycon.createStatement();
								s.execute("SELECT * FROM shop");
								rs=s.getResultSet();
				
								int dBrows=0;
								//calculating number of rows in db.
								
								s.execute("SELECT * FROM shop");
								rs=s.getResultSet();
								while(rs.next())
								{
									dBrows=dBrows+1;
									JTextArea jt = new JTextArea();
									jt.setFont(new Font("Arial", Font.PLAIN, 15));
									jt.setBackground(Color.ORANGE);
									jt.setText("SHOP"+(dBrows)+"\nName = "+rs.getString("name")+"\nAddress = "+rs.getString("address")+"\nRetail Space area = "+rs.getString("retspace")+"\nOpen time = "+rs.getString("open")+"\nClosing time ="+rs.getString("close")+"\nDuration of day service = "+rs.getInt("duration")+"\nService time per customer = "+rs.getInt("custserv"));
									panel1.add(jt);
								}
								s.close();
								mycon.close();
				
						}
						catch(SQLException ae)
						{
							ae.printStackTrace();
						}
						JPanel panel0 = new JPanel();
						panel0.setBackground(Color.gray);
						panel0.setLayout(new BoxLayout(panel0,BoxLayout.Y_AXIS));
						JLabel jlb = new JLabel("Operating Shops");
						jlb.setForeground(Color.white);
						jlb.setFont(new Font("Arial", Font.PLAIN, 100));
						jlb.setAlignmentX(CENTER_ALIGNMENT);
						JPanel panel2 = new JPanel(); 
						JButton Backbutton = new JButton("Back");
						Backbutton.addActionListener(new ActionListener()
						{
							public void actionPerformed(ActionEvent e)
							{
								Shopmenu sm = new Shopmenu();
								OperatingshopsFrame.this.dispose();
							}
						});

						Backbutton.setFont(new Font("Arial", Font.PLAIN, 50));
						Backbutton.setBackground(Color.orange);
						
						
						panel3.setSize(x, 150);
						panel2.setBackground(Color.gray);
						panel3.setBackground(Color.gray);
						panel2.add(Backbutton);
						panel0.add(jlb);
						panel0.add(panel1);
						panel0.add(panel3);
						panel0.add(panel2);
						this.setBackground(Color.gray);
						this.add(panel0);
						this.setVisible(true);
						this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				}
	
	
	

}
