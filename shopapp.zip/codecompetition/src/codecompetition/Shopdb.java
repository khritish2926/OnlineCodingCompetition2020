package codecompetition;

import java.sql.*;

public class Shopdb {

	public static void main(String[] args) {
		
		Connection con;
		Statement s;
		
		try {
			con=DriverManager.getConnection("jdbc:mysql://localhost/compete","root","12345");
			s=con.createStatement();
			//s.execute("DROP TABLE shop");
			s.execute("CREATE TABLE shop(name VARCHAR(25),address VARCHAR(25),retspace VARCHAR(25),open VARCHAR(5),close VARCHAR(5),duration INT,custserv INT)");
			s.execute("CREATE TABLE customer(fname VARCHAR(25),lname VARCHAR(25))");
			
			s.close();
			con.close();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}

	}

}
