package codecompetition;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class Shopmenu extends JFrame{

	Shopmenu()
	{
		super("Shops Menu");
		this.setResizable(false);
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		int x = (int)screenSize.getWidth();
		int y = (int)screenSize.getHeight();
		this.setSize(x,y);
		
		JButton bt1 = new JButton("Operating Shops");
		
		//adding action listener to bt1.
		bt1.addActionListener(new ActionListener()
		{
			
				public void actionPerformed(ActionEvent e) {
				OperatingshopsFrame op = new OperatingshopsFrame();
				Shopmenu.this.dispose();
				}
				
		});
		
		JButton bt2 = new JButton("Add New Shops");
		JButton bt3 = new JButton("Back");
		
		bt3.addActionListener(new ActionListener(){
			
			public void actionPerformed(ActionEvent e)
			{
				Welcome_frame frame3 = new Welcome_frame();
				Shopmenu.this.dispose();
			}
		});
		
		//adding action listener to bt2.
		bt2.addActionListener(new ActionListener()
				{
					public void actionPerformed(ActionEvent e)
					{
						AddShopFrame frame3 = new AddShopFrame();
						Shopmenu.this.dispose();
					}
				});
		bt1.setBackground(Color.orange);
		bt1.setFont(new Font("Arial", Font.PLAIN, 75));
		bt2.setFont(new Font("Arial", Font.PLAIN, 75));
		bt3.setFont(new Font("Arial", Font.PLAIN, 75));
		bt2.setBackground(Color.orange);
		bt3.setBackground(Color.orange);
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(0,3));
		panel.add(bt1);
		panel.add(bt2);
		panel.add(bt3);
		this.add(panel);
		this.setVisible(true);
	}
	

}
